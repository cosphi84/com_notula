DROP TABLE IF EXISTS `#__meetinig_participant`;
DROP TABLE IF EXISTS `#__meeting`;